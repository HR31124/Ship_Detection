import cv2
import time
import os
import threading
import queue
from ultralytics import YOLO
from engines.ocr_engine import ShipOCR
from utils.report_utils import save_test_report
from utils.connect import get_db_connection
from engines.speed_estimator import SpeedEstimator

class YoloTester:
    def __init__(self, model_path, input_source, output_folder,
                 conf=0.5, imgsz=640, stride=1, use_ocr=False):

        self.model_path = model_path
        self.input_source = input_source
        self.output_folder = output_folder
        self.conf = conf
        self.imgsz = imgsz
        self.stride = stride
        self.use_ocr = use_ocr
        self.stop_event = False

        print(f">> Loading YOLO: {model_path}")
        self.model = YOLO(model_path)

        self.ocr_queue = queue.Queue()
        self.ocr_engine = None

        if use_ocr:
            try:
                self.ocr_engine = ShipOCR()
                threading.Thread(target=self.ocr_worker, daemon=True).start()
            except Exception as e:
                print(f"Lỗi Init OCR: {e}")

        self.ocr_cache = {}
        self.current_objects = {}
        self.all_confs = []

        self.class_short = {
            "fishing_boat": "F",
            "speed_boat": "S",
            "passenger": "P",
            "passenger_ship": "P",
        }

        self.speed_estimator = None

    def ocr_worker(self):
        print(">> OCR Worker started...")
        while True:
            try:
                item = self.ocr_queue.get(timeout=0.5)
                track_id, crop_img, is_priority = item

                results = self.ocr_engine.ocr_image(crop_img)

                if results:
                    text = results[0]["text"]
                    score = results[0]["score"]
                    print(f">> OCR Result [ID {track_id}]: {text} ({int(score*100)}%)")

                    if track_id not in self.ocr_cache:
                        self.ocr_cache[track_id] = {"texts": [], "final": None}
                    self.ocr_cache[track_id]["final"] = text

                    conn = get_db_connection()
                    if conn:
                        try:
                            cursor = conn.cursor()
                            query = "UPDATE shiplog SET so_hieu = ? WHERE track_id = ?"
                            cursor.execute(query, (text, int(track_id)))
                            conn.commit()
                            print(f">> DB Updated: so_hieu = {text} cho track_id {track_id}")
                        except Exception as db_e:
                            print(f"DB Update Error: {db_e}")

                self.ocr_queue.task_done()
            except queue.Empty:
                if self.stop_event:
                    break
            except Exception as e:
                print(f"OCR Worker Error: {e}")

    def request_manual_ocr(self, track_id):
        if track_id in self.current_objects:
            obj = self.current_objects[track_id]
            print(f">> Clicked ID {track_id}. Requesting manual OCR...")
            self.ocr_queue.put((track_id, obj["crop"].copy(), True))

    def log_new_ship(self, track_id, class_name, crop_img=None):
        conn = get_db_connection()
        if not conn:
            print(">> Không kết nối được DB → bỏ qua log tàu mới")
            return

        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM shiplog WHERE track_id = ?", (int(track_id),))
            if cursor.fetchone()[0] == 0:
                img_path = None
                if crop_img is not None and crop_img.size > 0:
                    img_dir = os.path.join(self.output_folder, "ship_images")
                    os.makedirs(img_dir, exist_ok=True)
                    img_filename = f"ship_{track_id}_{int(time.time())}.jpg"
                    img_path = os.path.join(img_dir, img_filename)
                    cv2.imwrite(img_path, crop_img)
                    print(f">> Saved crop image: {img_path}")

                query = """
                    INSERT INTO shiplog 
                    (track_id, class_name, gio_phat_hien, hinh_anh_path) 
                    VALUES (?, ?, GETDATE(), ?)
                """
                cursor.execute(query, (int(track_id), class_name, img_path))
                conn.commit()
                print(f">> DB: Logged New Ship ID {track_id}")
        except Exception as e:
            print(f"DB Insert Error: {e}")

    def run(self, update_gui_callback):
        cap = cv2.VideoCapture(self.input_source)
        if not cap.isOpened():
            print(">> Không mở được video / camera!")
            return

        w_vid = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h_vid = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps_vid = cap.get(cv2.CAP_PROP_FPS) or 30.0

        self.speed_estimator = SpeedEstimator(
            fps=fps_vid,
            pixel_to_meter=0.05,
            history_length=12,
            smoothing_window=5
        )

        save_path = os.path.join(self.output_folder, f"result_{os.path.basename(self.input_source)}")
        out = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps_vid, (w_vid, h_vid))

        frame_count = 0
        data_report = []

        print(">> Video processing started...")
        while cap.isOpened() and not self.stop_event:
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1
            if frame_count % self.stride != 0:
                continue

            start_t = time.time()
            results = self.model.track(
                frame,
                conf=self.conf,
                imgsz=self.imgsz,
                persist=True,
                verbose=False,
                tracker="bytetrack.yaml"
            )
            res = results[0]
            annotated_frame = res.plot(labels=False)

            new_current_objects = {}
            current_ids_in_frame = set()

            if res.boxes.conf is not None:
                self.all_confs.extend(res.boxes.conf.cpu().numpy().tolist())

            if res.boxes.id is not None:
                boxes = res.boxes.xyxy.cpu().numpy().astype(int)
                ids = res.boxes.id.cpu().numpy().astype(int)
                cls_indices = res.boxes.cls.cpu().numpy().astype(int)
                names = self.model.names

                for i, (box, track_id, cls_idx) in enumerate(zip(boxes, ids, cls_indices)):
                    x1, y1, x2, y2 = box
                    current_ids_in_frame.add(track_id)
                    class_name = names[cls_idx]

                    class_short_map = {
                        "fishing_boat": "F",
                        "speed_boat": "S",
                        "passenger": "P",
                        "passenger_ship": "P",
                    }
                    short_class = class_short_map.get(class_name.lower(), class_name[0].upper())

                    crop_to_use = None
                    if track_id not in self.current_objects:
                        h, w, _ = frame.shape
                        cy1, cy2 = max(0, y1), min(h, y2)
                        cx1, cx2 = max(0, x1), min(w, x2)
                        crop_to_use = frame[cy1:cy2, cx1:cx2].copy()
                        self.log_new_ship(track_id, class_name, crop_to_use)
                    else:
                        crop_to_use = self.current_objects[track_id]["crop"]

                    _, speed_kmh = self.speed_estimator.update(track_id, box)

                    text_display = self.ocr_cache.get(track_id, {}).get("final", "...")

                    new_current_objects[track_id] = {
                        "bbox": (x1, y1, x2, y2),
                        "ocr": text_display,
                        "crop": crop_to_use,
                        "speed_kmh": speed_kmh,
                    }

                    short_label = f"id:{track_id} {short_class} {res.boxes.conf[i]:.2f}"
                    cv2.putText(annotated_frame, short_label,
                                (x1 + 5, y1 - 35 if text_display != "..." else y1 - 25),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

                    if text_display != "...":
                        cv2.putText(annotated_frame, text_display, (x1, y1 - 10),
                                    cv2.FONT_HERSHEY_COMPLEX, 0.8, (0, 255, 255), 2)

                    if speed_kmh > 0.5:
                        text_speed = f"{speed_kmh:.1f} km/h"
                        y_text = y1 - 55 if text_display != "..." else y1 - 45
                        cv2.putText(annotated_frame, text_speed, (x1, y_text),
                                    cv2.FONT_HERSHEY_DUPLEX, 0.85, (0, 0, 255), 3)

            lost_ids = set(self.current_objects.keys()) - current_ids_in_frame
            conn = get_db_connection()
            if conn and lost_ids:
                try:
                    cursor = conn.cursor()
                    for tid in lost_ids:
                        avg_speed = self.speed_estimator.get_average_kmh(tid)
                        if avg_speed > 0:
                            cursor.execute(
                                "UPDATE shiplog SET toc_do_tb = ? WHERE track_id = ?",
                                (avg_speed, int(tid))
                            )
                            print(f">> DB Updated: track_id {tid} - toc_do_tb = {avg_speed} km/h")
                    conn.commit()
                except Exception as e:
                    print(f"DB Update Speed Error: {e}")

            self.current_objects = new_current_objects
            self.speed_estimator.cleanup(current_ids_in_frame)

            out.write(annotated_frame)
            process_ms = (time.time() - start_t) * 1000
            fps = 1000.0 / process_ms if process_ms > 0 else 0
            update_gui_callback(annotated_frame, fps)

            data_report.append({
                "Frame": frame_count,
                "FPS": fps,
                "Objects": len(current_ids_in_frame),
                "Time_ms": process_ms
            })

        print(">> Processing finished.")

        cap.release()
        out.release()

        conn = get_db_connection()
        if conn and self.current_objects:
            try:
                cursor = conn.cursor()
                for tid in self.current_objects:
                    avg_speed = self.speed_estimator.get_average_kmh(tid)
                    if avg_speed > 0:
                        cursor.execute(
                            "UPDATE shiplog SET toc_do_tb = ? WHERE track_id = ?",
                            (avg_speed, int(tid))
                        )
                        print(f">> Final DB Update: track_id {tid} - toc_do_tb = {avg_speed} km/h")
                conn.commit()
            except Exception as e:
                print(f"Final DB Update Error: {e}")

        if data_report:
            processed_count = len(data_report)
            total_frames = frame_count

            ocr_data = {}
            for tid, info in self.ocr_cache.items():
                final_text = info.get("final")
                if final_text and final_text != "...":
                    ocr_data[tid] = final_text

            video_name = os.path.basename(self.input_source)
            model_name = os.path.basename(self.model_path)

            save_test_report(
                data=data_report,
                all_confs=self.all_confs,
                output_folder=self.output_folder,
                video_name=video_name,
                processed_count=processed_count,
                total_frames=total_frames,
                model_name=model_name,
                imgsz=self.imgsz,
                stride=self.stride,
                conf_thresh=self.conf,
                tag="AUTO_TEST",
                ocr_data=ocr_data
            )
            print(">> Báo cáo đã được tạo và lưu vào thư mục output.")
        else:
            print(">> Không có dữ liệu để tạo báo cáo.")

    def stop(self):
        self.stop_event = True